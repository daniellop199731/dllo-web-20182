Guia

git init -> para iniciar el git